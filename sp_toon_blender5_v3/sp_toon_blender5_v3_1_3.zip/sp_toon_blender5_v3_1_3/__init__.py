# SPDX-License-Identifier: GPL-2.0-or-later

bl_info = {
    "name": "SP Toon Shader for Blender 5 v3.1.3",
    "author": "DiGiMonkey",
    "version": (3, 1, 3),
    "blender": (5, 0, 0),
    "location": "Shader Editor > Sidebar > SP Toon",
    "description": "Toon shader with reversible facing outline and explicit curvature-map assignment",
    "category": "Material",
}

import bpy
from bpy.props import (
    BoolProperty,
    FloatProperty,
    FloatVectorProperty,
    PointerProperty,
)
from bpy.types import Operator, Panel, PropertyGroup


GROUP_NAME = "SP_Toon_Blender5_v3_1"
MATERIAL_NAME = "SP_Toon_Blender5_Material_v3_1"


def clear_interface(interface):
    for item in list(interface.items_tree):
        interface.remove(item)


def new_socket(interface, name, in_out, socket_type, default=None, minimum=None, maximum=None):
    socket = interface.new_socket(
        name=name,
        in_out=in_out,
        socket_type=socket_type,
    )

    if default is not None and hasattr(socket, "default_value"):
        socket.default_value = default

    if minimum is not None and hasattr(socket, "min_value"):
        socket.min_value = minimum

    if maximum is not None and hasattr(socket, "max_value"):
        socket.max_value = maximum

    return socket


def math_node(nodes, operation, x, y, label):
    node = nodes.new("ShaderNodeMath")
    node.operation = operation
    node.location = (x, y)
    node.label = label
    return node


def inverse_smooth_mask(tree, value_socket, threshold_socket, blur_socket, x, y, label):
    nodes = tree.nodes
    links = tree.links

    safe_blur = math_node(nodes, "MAXIMUM", x, y, label + " Safe Blur")
    safe_blur.inputs[1].default_value = 0.000001
    links.new(blur_socket, safe_blur.inputs[0])

    lower = math_node(nodes, "SUBTRACT", x + 170, y + 45, label + " Lower")
    upper = math_node(nodes, "ADD", x + 170, y - 65, label + " Upper")
    links.new(threshold_socket, lower.inputs[0])
    links.new(safe_blur.outputs[0], lower.inputs[1])
    links.new(threshold_socket, upper.inputs[0])
    links.new(safe_blur.outputs[0], upper.inputs[1])

    mapper = nodes.new("ShaderNodeMapRange")
    mapper.location = (x + 380, y)
    mapper.label = label
    mapper.clamp = True
    mapper.interpolation_type = "SMOOTHSTEP"
    mapper.inputs["To Min"].default_value = 1.0
    mapper.inputs["To Max"].default_value = 0.0

    links.new(value_socket, mapper.inputs["Value"])
    links.new(lower.outputs[0], mapper.inputs["From Min"])
    links.new(upper.outputs[0], mapper.inputs["From Max"])

    return mapper.outputs["Result"]


def mix_color(tree, factor, color_a, color_b, x, y, label):
    node = tree.nodes.new("ShaderNodeMixRGB")
    node.blend_type = "MIX"
    node.location = (x, y)
    node.label = label
    tree.links.new(factor, node.inputs["Fac"])
    tree.links.new(color_a, node.inputs["Color1"])
    tree.links.new(color_b, node.inputs["Color2"])
    return node.outputs["Color"]


def build_toon_group():
    group = bpy.data.node_groups.get(GROUP_NAME)

    if group is None:
        group = bpy.data.node_groups.new(GROUP_NAME, "ShaderNodeTree")

    group.nodes.clear()
    clear_interface(group.interface)

    interface = group.interface

    new_socket(interface, "Shader", "OUTPUT", "NodeSocketShader")
    new_socket(interface, "Color", "OUTPUT", "NodeSocketColor")

    new_socket(interface, "Light Position", "INPUT", "NodeSocketVector", (10.0, 10.0, 10.0))
    new_socket(interface, "Use Outline", "INPUT", "NodeSocketFloat", 1.0, 0.0, 1.0)
    new_socket(interface, "Reverse Outline", "INPUT", "NodeSocketFloat", 1.0, 0.0, 1.0)
    new_socket(interface, "Outline Thickness", "INPUT", "NodeSocketFloat", 0.6, 0.0, 1.0)
    new_socket(interface, "Outline Blur", "INPUT", "NodeSocketFloat", 0.0, 0.0, 5.0)
    new_socket(interface, "Inline Thickness", "INPUT", "NodeSocketFloat", 0.14, 0.0, 1.0)
    new_socket(interface, "Inline Blur", "INPUT", "NodeSocketFloat", 0.0, 0.0, 5.0)
    
    # Placed right under Inline Blur
    new_socket(interface, "Inline on Top", "INPUT", "NodeSocketFloat", 1.0, 0.0, 1.0)
    
    new_socket(interface, "Curvature", "INPUT", "NodeSocketFloat", 1.0, 0.0, 1.0)

    defaults = [0.0, -0.5, -1.0, -1.0, -1.0, -1.0]
    for index, value in enumerate(defaults, start=2):
        new_socket(
            interface,
            f"Toon Param {index}",
            "INPUT",
            "NodeSocketFloat",
            value,
            -1.0,
            1.0,
        )

    new_socket(interface, "Toon Blur", "INPUT", "NodeSocketFloat", 0.0, 0.0, 5.0)
    
    # Default colors with gamma correction
    new_socket(interface, "Base Color", "INPUT", "NodeSocketColor", (1.0, 1.0, 1.0, 1.0))
    new_socket(interface, "Outline Color", "INPUT", "NodeSocketColor", (0.0, 0.297, 1.0, 1.0))
    new_socket(interface, "Inline Color", "INPUT", "NodeSocketColor", (0.366, 0.027, 0.0, 1.0))

    toon_colors = [
        (0.554, 0.554, 0.554, 1.0),
        (0.232, 0.232, 0.232, 1.0),
        (0.095, 0.095, 0.095, 1.0),
        (0.070, 0.070, 0.070, 1.0),
        (0.025, 0.025, 0.025, 1.0),
        (0.016, 0.016, 0.016, 1.0),
    ]

    for index, value in enumerate(toon_colors, start=2):
        new_socket(interface, f"Toon Color {index}", "INPUT", "NodeSocketColor", value)

    nodes = group.nodes
    links = group.links

    group_input = nodes.new("NodeGroupInput")
    group_input.location = (-1800, 100)

    group_output = nodes.new("NodeGroupOutput")
    group_output.location = (2300, 100)

    geometry = nodes.new("ShaderNodeNewGeometry")
    geometry.location = (-1800, 620)

    subtract = nodes.new("ShaderNodeVectorMath")
    subtract.operation = "SUBTRACT"
    subtract.location = (-1550, 620)
    links.new(group_input.outputs["Light Position"], subtract.inputs[0])
    links.new(geometry.outputs["Position"], subtract.inputs[1])

    normalize_light = nodes.new("ShaderNodeVectorMath")
    normalize_light.operation = "NORMALIZE"
    normalize_light.location = (-1350, 620)
    links.new(subtract.outputs["Vector"], normalize_light.inputs[0])

    dot_light = nodes.new("ShaderNodeVectorMath")
    dot_light.operation = "DOT_PRODUCT"
    dot_light.location = (-1150, 620)
    links.new(geometry.outputs["Normal"], dot_light.inputs[0])
    links.new(normalize_light.outputs["Vector"], dot_light.inputs[1])

    current_color = group_input.outputs["Base Color"]
    y = 480

    for index in range(2, 8):
        mask = inverse_smooth_mask(
            group,
            dot_light.outputs["Value"],
            group_input.outputs[f"Toon Param {index}"],
            group_input.outputs["Toon Blur"],
            -980,
            y,
            f"Toon Band {index}",
        )
        current_color = mix_color(
            group,
            mask,
            current_color,
            group_input.outputs[f"Toon Color {index}"],
            -260 + ((index - 2) * 230),
            y,
            f"Toon Color {index}",
        )
        y -= 160

    # Shader-based outline from camera-facing angle.
    layer_weight = nodes.new("ShaderNodeLayerWeight")
    layer_weight.location = (500, -760)
    layer_weight.label = "Outline Facing"

    raw_outline_mask = inverse_smooth_mask(
        group,
        layer_weight.outputs["Facing"],
        group_input.outputs["Outline Thickness"],
        group_input.outputs["Outline Blur"],
        700,
        -760,
        "Outline",
    )

    invert_outline = math_node(nodes, "SUBTRACT", 1080, -760, "Invert Outline Mask")
    invert_outline.inputs[0].default_value = 1.0
    links.new(raw_outline_mask, invert_outline.inputs[1])

    choose_outline = nodes.new("ShaderNodeMix")
    choose_outline.data_type = "FLOAT"
    choose_outline.location = (1270, -690)
    choose_outline.label = "Normal / Reversed Outline"
    links.new(group_input.outputs["Reverse Outline"], choose_outline.inputs["Factor"])
    links.new(raw_outline_mask, choose_outline.inputs["A"])
    links.new(invert_outline.outputs[0], choose_outline.inputs["B"])

    outline_enabled = math_node(nodes, "MULTIPLY", 1470, -690, "Use Outline")
    links.new(choose_outline.outputs["Result"], outline_enabled.inputs[0])
    links.new(group_input.outputs["Use Outline"], outline_enabled.inputs[1])

    inline_mask = inverse_smooth_mask(
        group,
        group_input.outputs["Curvature"],
        group_input.outputs["Inline Thickness"],
        group_input.outputs["Inline Blur"],
        650,
        -620,
        "Inline",
    )

    # Path A: Toon -> Inline -> Outline (Outline on top)
    path_a_inline = mix_color(
        group,
        inline_mask,
        current_color,
        group_input.outputs["Inline Color"],
        1050,
        -180,
        "Path A: Apply Inline First",
    )
    path_a_final = mix_color(
        group,
        outline_enabled.outputs[0],
        path_a_inline,
        group_input.outputs["Outline Color"],
        1300,
        -180,
        "Path A: Outline Last",
    )

    # Path B: Toon -> Outline -> Inline (Inline on top)
    path_b_outline = mix_color(
        group,
        outline_enabled.outputs[0],
        current_color,
        group_input.outputs["Outline Color"],
        1050,
        -450,
        "Path B: Apply Outline First",
    )
    path_b_final = mix_color(
        group,
        inline_mask,
        path_b_outline,
        group_input.outputs["Inline Color"],
        1300,
        -450,
        "Path B: Inline Last",
    )

    # Switch between Path A and Path B using Inline on Top factor
    switch_node = nodes.new("ShaderNodeMix")
    switch_node.data_type = "RGBA"
    switch_node.blend_type = "MIX"
    switch_node.location = (1650, -300)
    switch_node.label = "Select Layer Order"
    links.new(group_input.outputs["Inline on Top"], switch_node.inputs["Factor"])
    links.new(path_a_final, switch_node.inputs["A"])
    links.new(path_b_final, switch_node.inputs["B"])

    final_color = switch_node.outputs["Result"]

    emission = nodes.new("ShaderNodeEmission")
    emission.location = (2050, 100)
    emission.inputs["Strength"].default_value = 1.0
    links.new(final_color, emission.inputs["Color"])

    links.new(emission.outputs["Emission"], group_output.inputs["Shader"])
    links.new(final_color, group_output.inputs["Color"])

    return group


def build_main_material(settings):
    group = build_toon_group()
    material = bpy.data.materials.get(MATERIAL_NAME)
    if material is None:
        material = bpy.data.materials.new(MATERIAL_NAME)
    material.use_nodes = True
    tree = material.node_tree
    tree.nodes.clear()

    texcoord = tree.nodes.new("ShaderNodeTexCoord")
    texcoord.location = (-850, -280)

    image = tree.nodes.new("ShaderNodeTexImage")
    image.name = "SP_INLINE_CURVATURE_MAP"
    image.label = "INLINE CURVATURE MAP"
    image.location = (-620, -280)
    image.image = settings.curvature_image
    image.interpolation = "Linear"
    image.extension = "REPEAT"
    tree.links.new(texcoord.outputs["UV"], image.inputs["Vector"])

    rgb_to_bw = tree.nodes.new("ShaderNodeRGBToBW")
    rgb_to_bw.name = "SP_CURVATURE_TO_VALUE"
    rgb_to_bw.location = (-390, -280)
    tree.links.new(image.outputs["Color"], rgb_to_bw.inputs["Color"])

    invert = tree.nodes.new("ShaderNodeInvert")
    invert.name = "SP_CURVATURE_INVERT"
    invert.location = (-180, -370)
    tree.links.new(rgb_to_bw.outputs["Val"], invert.inputs["Color"])

    selector = tree.nodes.new("ShaderNodeMixRGB")
    selector.name = "SP_CURVATURE_DIRECTION"
    selector.label = "Curvature Normal / Inverted"
    selector.blend_type = "MIX"
    selector.location = (40, -270)
    selector.inputs["Fac"].default_value = 1.0 if settings.curvature_invert else 0.0
    tree.links.new(rgb_to_bw.outputs["Val"], selector.inputs["Color1"])
    tree.links.new(invert.outputs["Color"], selector.inputs["Color2"])

    group_node = tree.nodes.new("ShaderNodeGroup")
    group_node.node_tree = group
    group_node.name = "SP Toon Controls"
    group_node.label = "SP Toon Controls"
    group_node.location = (300, 0)
    group_node.width = 360

    if settings.curvature_image is None:
        group_node.inputs["Curvature"].default_value = 1.0
    else:
        tree.links.new(selector.outputs["Color"], group_node.inputs["Curvature"])

    output = tree.nodes.new("ShaderNodeOutputMaterial")
    output.location = (760, 0)
    tree.links.new(group_node.outputs["Shader"], output.inputs["Surface"])

    return material


class SPToonSettings(PropertyGroup):
    curvature_image: PointerProperty(name="Inline Curvature Map", type=bpy.types.Image)
    curvature_invert: BoolProperty(name="Invert Curvature", default=False)


class SPTOON_OT_create_material(Operator):
    bl_idname = "sp_toon_v3_1.create_material"
    bl_label = "Create / Update Toon Material"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        if obj is None or not hasattr(obj.data, "materials"):
            self.report({"ERROR"}, "Select a mesh object.")
            return {"CANCELLED"}
        settings = context.scene.sp_toon_settings
        material = build_main_material(settings)
        if obj.data.materials:
            obj.data.materials[0] = material
        else:
            obj.data.materials.append(material)
        self.report({"INFO"}, "SP Toon material created.")
        return {"FINISHED"}


class SPTOON_OT_update_curvature(Operator):
    bl_idname = "sp_toon_v3_1.update_curvature"
    bl_label = "Apply Curvature Map"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        settings = context.scene.sp_toon_settings
        material = build_main_material(settings)
        obj = context.active_object
        if obj is not None and hasattr(obj.data, "materials"):
            if obj.data.materials:
                obj.data.materials[0] = material
            else:
                obj.data.materials.append(material)
        self.report({"INFO"}, "Curvature map updated.")
        return {"FINISHED"}


class SPTOON_PT_panel(Panel):
    bl_label = "SP Toon v3.1.3"
    bl_idname = "SPTOON_PT_panel_v3_1"
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = "SP Toon"

    @classmethod
    def poll(cls, context):
        return (context.area is not None and context.area.type == "NODE_EDITOR" and context.space_data.tree_type == "ShaderNodeTree")

    def draw(self, context):
        layout = self.layout
        settings = context.scene.sp_toon_settings

        material_box = layout.box()
        material_box.label(text="Toon Material")
        material_box.operator("sp_toon_v3_1.create_material", icon="MATERIAL")

        inline_box = layout.box()
        inline_box.label(text="Inline Curvature Map")
        inline_box.prop(settings, "curvature_image")
        inline_box.prop(settings, "curvature_invert")
        inline_box.operator("sp_toon_v3_1.update_curvature", icon="FILE_REFRESH")
        inline_box.label(text='Node: "INLINE CURVATURE MAP"')

        outline_box = layout.box()
        outline_box.label(text="Shader Outline")
        outline_box.label(text="Adjust in SP Toon Controls node:")
        outline_box.label(text="Use Outline / Reverse Outline")
        outline_box.label(text="Outline Thickness / Blur / Color")

        note = layout.box()
        note.label(text="Reverse Outline is ON by default.")
        note.label(text="This is a surface-facing outline.")


classes = (SPToonSettings, SPTOON_OT_create_material, SPTOON_OT_update_curvature, SPTOON_PT_panel)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.sp_toon_settings = PointerProperty(type=SPToonSettings)

def unregister():
    del bpy.types.Scene.sp_toon_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
