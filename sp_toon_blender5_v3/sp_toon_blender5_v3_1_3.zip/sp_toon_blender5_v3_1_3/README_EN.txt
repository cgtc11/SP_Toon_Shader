SP Toon Shader for Blender 5 v3.1.3
Maintainer: DiGiMonkey

Changelog:
- Updated version structure and bl_info to v3.1.3
- Changed default Base Color to complete white (1, 1, 1, 1)
- UI panels and internal text converted to English
- Default color values updated to custom palette presets
- Added dynamic layering feature via 'Inline on Top' switch inside the shader node controls.
- Reordered node input sockets so that 'Inline on Top' sits perfectly right below 'Inline Blur'.
